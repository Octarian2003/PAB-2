package com.example.daftar_belanja

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
